module.exports = {
  apps : [
    {
      name: 'poll',
      script: 'bin/www',
      watch: false
    //  ignore_watch: ["public/images/*"]
    }
  ],
};